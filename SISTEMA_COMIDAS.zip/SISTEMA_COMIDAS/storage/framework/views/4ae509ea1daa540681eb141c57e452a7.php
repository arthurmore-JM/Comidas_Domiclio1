

<?php $__env->startSection('title', 'Sazón — comida que llega al corazón'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero">
    <div class="container hero-grid">
        <div class="hero-copy">
            <span class="eyebrow"><span class="eyebrow-line"></span> SABOR CASERO, A TU PUERTA</span>
            <h1>Tu próxima comida<br>favorita <em>está aquí.</em></h1>
            <p>Recetas llenas de sabor, ingredientes frescos y ese toque casero que convierte cualquier día en uno especial.</p>
            <div class="hero-actions"><a class="button button-primary" href="#menu">Explorar el menú <span>↘</span></a><a class="text-link" href="<?php echo e(route('reservations.index')); ?>">¿Prefieres reservar? <span>→</span></a></div>
            <div class="hero-proof"><div class="avatar-stack"><span>M</span><span>A</span><span>J</span></div><div><strong>4.9/5</strong><small>Más de 1,200 clientes felices</small></div><span class="proof-star">★★★★★</span></div>
        </div>
        <div class="hero-visual">
            <div class="hero-image"></div>
            <div class="hero-sticker"><span>✦</span><strong>Fresco<br>y delicioso</strong><small>hecho hoy, para ti</small></div>
            <div class="hero-note"><span class="note-icon">↗</span><span><strong>Entrega rápida</strong><small>Tu cocina está a minutos</small></span></div>
        </div>
    </div>
</section>
<section class="benefits">
    <div class="container benefits-grid">
        <div><span class="benefit-icon">✿</span><span><strong>Ingredientes frescos</strong><small>Elegidos cada día</small></span></div>
        <div><span class="benefit-icon">⌁</span><span><strong>Entrega cuidadosa</strong><small>Caliente hasta tu puerta</small></span></div>
        <div><span class="benefit-icon">♡</span><span><strong>Hecho con cariño</strong><small>Como en casa</small></span></div>
        <div><span class="benefit-icon">✦</span><span><strong>Pago a tu manera</strong><small>Efectivo, tarjeta o transferencia</small></span></div>
    </div>
</section>
<section class="section menu-section" id="menu">
    <div class="container">
        <div class="section-heading"><div><span class="eyebrow"><span class="eyebrow-line"></span> SABORES DEL PERÚ Y MÁS</span><h2>Un menú para cada antojo</h2>        <p>Explora platos criollos, opciones a la carta, entradas, postres y más.</p></div><span class="menu-count"><?php echo e($foods->count()); ?> opciones</span></div>
        <?php if($categories->isNotEmpty()): ?>
            <nav class="category-filters" aria-label="Filtrar comidas por categoría">
                <a class="<?php echo e($selectedCategory === null ? 'active' : ''); ?>" href="<?php echo e(route('foods.index')); ?>#menu" <?php if($selectedCategory === null): ?> aria-current="page" <?php endif; ?>>Todos</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="<?php echo e($selectedCategory === $category ? 'active' : ''); ?>" href="<?php echo e(route('foods.index', ['category' => $category])); ?>#menu" <?php if($selectedCategory === $category): ?> aria-current="page" <?php endif; ?>><?php echo e($category); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        <?php endif; ?>
        <?php if($foods->isEmpty()): ?>
            <div class="empty-state"><span>🍽️</span><h3>Estamos preparando el menú</h3><p>Muy pronto encontrarás aquí algo delicioso.</p></div>
        <?php else: ?>
            <div class="food-grid">
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $image = $food->image_path ? (filter_var($food->image_path, FILTER_VALIDATE_URL) ? $food->image_path : \Illuminate\Support\Facades\Storage::disk('public')->url($food->image_path)) : null; ?>
                    <article class="food-card">
                        <div class="food-photo" <?php if($image): ?> style="background-image:url('<?php echo e($image); ?>')" <?php endif; ?>>
                            <?php if($food->offer_price): ?><span class="food-tag">OFERTA</span><?php elseif($food->is_featured): ?><span class="food-tag food-tag-soft">FAVORITO</span><?php endif; ?>
                            <span class="food-category"><?php echo e($food->category); ?></span>
                        </div>
                        <div class="food-info"><div class="food-title-row"><h3><?php echo e($food->name); ?></h3><span class="food-rating">★ 4.9</span></div><p><?php echo e($food->description); ?></p><div class="food-bottom"><div class="price"><?php if($food->offer_price): ?><del>$<?php echo e(number_format($food->price, 2)); ?></del><?php endif; ?> <strong>$<?php echo e(number_format($food->offer_price ?? $food->price, 2)); ?></strong></div><form method="POST" action="<?php echo e(route('cart.add', $food)); ?>"><?php echo csrf_field(); ?><button class="add-button" type="submit" aria-label="Agregar <?php echo e($food->name); ?> al carrito">+</button></form></div></div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<section class="offer-banner"><div class="container offer-content"><span class="offer-spark">✳</span><div><span class="eyebrow">UN PEQUEÑO DETALLE PARA TI</span><h2>Tu antojo de hoy merece algo especial.</h2><p>Descubre nuestras ofertas y encuentra tu nuevo favorito.</p></div><a class="button button-white" href="#menu">Ver el menú <span>→</span></a></div></section>
<section class="section reservation-cta"><div class="container reservation-card"><div><span class="eyebrow"><span class="eyebrow-line"></span> UN MOMENTO PARA COMPARTIR</span><h2>¿Una ocasión especial?</h2><p>Reserva tu horario y déjanos hacer que el momento sea aún más rico.</p></div><a class="button button-primary" href="<?php echo e(route('reservations.index')); ?>">Hacer una reserva <span>→</span></a></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\SISTEMA_COMIDAS\resources\views/store/home.blade.php ENDPATH**/ ?>