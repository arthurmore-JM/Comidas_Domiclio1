
<?php $__env->startSection('title', 'Acceso administrativo — Sazón'); ?>
<?php $__env->startSection('content'); ?>
<section class="admin-login-card">
    <span class="eyebrow"><span class="eyebrow-line"></span> ACCESO RESTRINGIDO</span>
    <h1>Administración</h1>
    <p>Ingresa con la cuenta del equipo para gestionar el restaurante.</p>
    <form method="POST" action="<?php echo e(route('admin.login.store')); ?>" class="form-stack">
        <?php echo csrf_field(); ?>
        <label>Correo administrativo<input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="admin@restaurante.com" required autocomplete="username" autofocus></label>
        <label>Contraseña<input type="password" name="password" placeholder="Tu contraseña" required autocomplete="current-password"></label>
        <label class="check-label"><input type="checkbox" name="remember"> Recordarme</label>
        <button class="button button-primary button-full" type="submit">Entrar al panel <span>→</span></button>
    </form>
    <p class="auth-switch">¿Buscas hacer un pedido? <a href="<?php echo e(route('login')); ?>">Ingresa como cliente</a></p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\SISTEMA_COMIDAS\resources\views/auth/admin-login.blade.php ENDPATH**/ ?>