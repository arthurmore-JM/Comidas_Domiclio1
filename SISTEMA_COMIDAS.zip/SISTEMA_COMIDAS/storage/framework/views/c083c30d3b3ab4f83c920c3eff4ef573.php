<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Sazón — comida que llega al corazón'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=8">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark">S</span><span>Sazón<span class="brand-dot">.</span><small>COMIDA HECHA CON AMOR</small></span></a>
        <button class="menu-toggle" type="button" aria-label="Abrir menú" onclick="document.body.classList.toggle('nav-open')">☰</button>
        <nav class="main-nav">
            <a href="<?php echo e(route('home')); ?>">Inicio</a>
            <a href="<?php echo e(route('foods.index')); ?>#menu">Menú</a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Panel administrativo</a>
                <?php else: ?>
                    <a href="<?php echo e(route('customer.dashboard')); ?>">Mi cuenta</a>
                    <a href="<?php echo e(route('reservations.index')); ?>">Reservas</a>
                    <a href="<?php echo e(route('orders.mine')); ?>">Mis pedidos</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Acceso de clientes</a>
                <a href="<?php echo e(route('admin.login')); ?>">Acceso administrativo</a>
            <?php endif; ?>
        </nav>
        <div class="nav-actions">
            <?php if(!auth()->check() || auth()->user()->role !== 'admin'): ?>
                <a class="cart-link" href="<?php echo e(route('cart.index')); ?>">Carrito <span class="cart-count"><?php echo e(collect(session('cart', []))->sum()); ?></span></a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <span class="nav-user"><?php echo e(auth()->user()->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="nav-logout" type="submit">Salir</button></form>
            <?php else: ?>
                <a class="nav-login" href="<?php echo e(route('login')); ?>">Ingresar como cliente</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<main>
    <?php if(session('success') || $errors->any()): ?>
        <div class="container flash-stack">
            <?php if(session('success')): ?><div class="flash flash-success"><?php echo e(session('success')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?><div class="flash flash-error"><?php echo e($errors->first()); ?></div><?php endif; ?>
        </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="site-footer">
    <div class="container footer-row"><a class="brand brand-light" href="<?php echo e(route('home')); ?>"><span class="brand-mark">S</span><span>Sazón<span class="brand-dot">.</span><small>COMIDA HECHA CON AMOR</small></span></a><p>Buenos momentos, servidos a domicilio.</p><span>© <?php echo e(date('Y')); ?> Sazón</span></div>
</footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SISTEMA_COMIDAS\resources\views/layouts/app.blade.php ENDPATH**/ ?>