
<?php $__env->startSection('title', 'Ingresar — Sazón'); ?>
<?php $__env->startSection('content'); ?>
<section class="auth-section"><div class="auth-card"><span class="eyebrow"><span class="eyebrow-line"></span> ACCESO DE CLIENTE</span><h1>Bienvenido de vuelta</h1><p>Ingresa a tu cuenta para pedir comida, reservar y revisar tus pedidos.</p>
    <form method="POST" action="<?php echo e(route('login.store')); ?>" class="form-stack"><?php echo csrf_field(); ?>
        <label>Correo electrónico<input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="tu@correo.com" required autocomplete="email" autofocus></label>
        <label>Contraseña<input type="password" name="password" placeholder="Tu contraseña" required autocomplete="current-password"></label>
        <label class="check-label"><input type="checkbox" name="remember"> Recordarme</label>
        <button class="button button-primary button-full" type="submit">Ingresar <span>→</span></button>
    </form>
    <p class="auth-switch">¿Aún no tienes cuenta? <a href="<?php echo e(route('register')); ?>">Crea una aquí</a></p>
    <p class="auth-switch">¿Eres administrador? <a href="<?php echo e(route('admin.login')); ?>">Ingresa al acceso administrativo</a></p>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\SISTEMA_COMIDAS\resources\views/auth/login.blade.php ENDPATH**/ ?>