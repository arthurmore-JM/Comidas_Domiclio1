<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Administración — Sazón'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=8">
</head>
<body class="admin-auth-body">
    <header class="admin-auth-header">
        <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark">S</span><span>Sazón<span class="brand-dot">.</span><small>ADMINISTRACIÓN</small></span></a>
        <span class="admin-auth-badge">Panel privado</span>
    </header>
    <main class="admin-auth-main">
        <?php if($errors->any()): ?>
            <div class="flash flash-error admin-auth-error"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="admin-auth-footer"><a href="<?php echo e(route('login')); ?>">← Volver al acceso de clientes</a></footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SISTEMA_COMIDAS\resources\views/layouts/admin-auth.blade.php ENDPATH**/ ?>